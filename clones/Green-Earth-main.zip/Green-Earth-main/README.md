## What is the difference between var, let, and const?
var is function-scoped and can be redeclared and updated and let is block-scoped, can be updated but not redeclared in the same scope.
## What is the difference between map(), forEach(), and filter()?
map() creates a new array by applying a function to each element, forEach() executes a function on each element but returns nothing and filter() creates a new array with elements that pass a test function.
##  What are arrow functions in ES6?
Arrow functions in ES6 are a shorter syntax for writing functions using =>. They do not have their own this context and inherit it from the surrounding code, making them simpler and more concise.
## How does destructuring assignment work in ES6?
The ES6 lets you quickly take values from arrays or objects and store them in variables with simple, clear code. For example, you can write let {name, age} = person; to get name and age from an object.
## How does destructuring assignment work in ES6?
Template literals in ES6 are strings wrapped in backticks () that allow embedding variables and expressions inside with ${}. They support multi-line strings easily, unlike traditional string concatenation which uses quotes and the +` operator to join strings [][][].
